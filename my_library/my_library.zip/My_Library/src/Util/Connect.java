package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect {
	Connection conn;
	
	public Connection getConn() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("���ݿ���سɹ���");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("���ݿ����ʧ�ܣ�");
			e.printStackTrace();
		}
		
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_library?characterEncoding=UTF-8", 
					"root", "123456");
			
			System.out.println("���ݿ����ӳɹ���");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("���ݿ�����ʧ�ܣ�");
			e.printStackTrace();
		}
		return conn;
	}
	
}
