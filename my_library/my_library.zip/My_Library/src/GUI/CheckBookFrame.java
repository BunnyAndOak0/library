package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.management.loading.PrivateClassLoader;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import com.sun.security.auth.NTDomainPrincipal;

import Dao.BookDao;
import Dao.BrowrroAndReturnInfoDao;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.Border;
import jdk.internal.dynalink.beans.StaticClass;


//���Ĺ黹����
public class CheckBookFrame extends JFrame{
	private JFrame checkBookFrame = new JFrame();
	private Container container = checkBookFrame.getContentPane();
	JComboBox comboBox;
	static DefaultTableModel tableModel;
	private JTextField bookCheckJTextField = new JTextField();
	private JButton checkBookButton = new JButton("��ѯ");
	private JButton allBookButton = new JButton("�鵥��ʾ");
	private JLabel bookNum = new JLabel("���");
	private JTextField bookNumField = new JTextField();
	private JLabel bookname = new JLabel("ͼ������");
	private JTextField booknameField = new JTextField();
	private JLabel aurthor = new JLabel("����");
	private JTextField aurthorField = new JTextField();
	private JLabel publish = new JLabel("������");
	private JTextField publishField = new JTextField();
	private JLabel bookStatue = new JLabel("״̬");
	private JTextField bookStatueField = new JTextField();
	private JButton borrowButton = new JButton("����");
	private JButton returnButton = new JButton("�黹");
	private String name;
	
	BookDao bookDao = new BookDao();
	
	public CheckBookFrame(String name) {
		this.name = name;
		checkBookFrame.setSize(1000, 700);
		checkBookFrame.setLocation(500, 150);
		checkBookFrame.setTitle("ͼ����ġ��黹����");
		checkBookFrame.setResizable(false);
		
		container.setLayout(new GridLayout(1, 2));     //��������Ϊ����������
		ini();
		
		checkBookFrame.setVisible(true);
		checkBookFrame.setDefaultCloseOperation(checkBookFrame.DISPOSE_ON_CLOSE);
		
	}
	
	private void ini() {
		//��߲���
		JPanel leftJPanel = new JPanel();
		leftJPanel.setLayout(new GridLayout(8, 1));
		leftJPanel.setBorder(new LineBorder(Color.white));
		
		//ͼ�����ֲ�ѯ����
		JPanel lCheckNameJPanel = new JPanel();
		lCheckNameJPanel.setLayout(null);
		String[] checkWays = new String[] {"ͼ������", "����", "������"};
		comboBox = new JComboBox(checkWays);
		comboBox.setBounds(50, 30, 115, 30);
		bookCheckJTextField.setBounds(210, 30, 200, 30);
		lCheckNameJPanel.add(comboBox);
		lCheckNameJPanel.add(bookCheckJTextField);
		leftJPanel.add(lCheckNameJPanel);
		
		//��ѯ��ť
		JPanel lcheckbookButtonJPanel = new JPanel();
		lcheckbookButtonJPanel.setLayout(null);
		checkBookButton.setBounds(100, 10, 100, 30);
		allBookButton.setBounds(260, 10, 100, 30);
//		checkBookButton���¼�����������ĩβ  ��ȻtableModel�ĸ�ֵ����ֿ�ָ�������
		lcheckbookButtonJPanel.add(checkBookButton);
		lcheckbookButtonJPanel.add(allBookButton);
		leftJPanel.add(lcheckbookButtonJPanel);
		//���
		JPanel lbookNumJPanel = new JPanel();
		lbookNumJPanel.setLayout(null);
		bookNum.setFont(new Font("����", Font.BOLD, 20));
		bookNum.setBounds(50, 30, 100, 30);
		bookNumField.setBounds(175, 30, 175, 30);
		lbookNumJPanel.add(bookNum);
		lbookNumJPanel.add(bookNumField);
		leftJPanel.add(lbookNumJPanel);
		//ͼ����
		JPanel lbookNameJPanel = new JPanel();
		lbookNameJPanel.setLayout(null);
		bookname.setFont(new Font("����", Font.BOLD, 20));
		bookname.setBounds(50, 30, 100, 30);
		booknameField.setBounds(175, 30, 175, 30);
		lbookNameJPanel.add(bookname);
		lbookNameJPanel.add(booknameField);
		leftJPanel.add(lbookNameJPanel);
		//����
		JPanel laurthorJPanel = new JPanel();
		laurthorJPanel.setLayout(null);
		aurthor.setFont(new Font("����", Font.BOLD, 20));
		aurthor.setBounds(50, 30, 100, 30);
		aurthorField.setBounds(175, 30, 175, 30);
		laurthorJPanel.add(aurthor);
		laurthorJPanel.add(aurthorField);
		leftJPanel.add(laurthorJPanel);
		//������
		JPanel lpublishJPanel = new JPanel();
		lpublishJPanel.setLayout(null);
		publish.setFont(new Font("����", Font.BOLD, 20));
		publish.setBounds(50, 30, 100, 30);
		publishField.setBounds(175, 30, 175, 30);
		lpublishJPanel.add(publish);
		lpublishJPanel.add(publishField);
		leftJPanel.add(lpublishJPanel);
		//״̬
		JPanel lbookStatueJPanel = new JPanel();
		lbookStatueJPanel.setLayout(null);
		bookStatue.setFont(new Font("����", Font.BOLD, 20));
		bookStatue.setBounds(50, 30, 100, 30);
		bookStatueField.setBounds(175, 30, 175, 30);
		lbookStatueJPanel.add(bookStatue);
		lbookStatueJPanel.add(bookStatueField);
		leftJPanel.add(lbookStatueJPanel);
		//���Ĺ黹��ť
		JPanel brJPanel = new JPanel();
		brJPanel.setLayout(null);
		borrowButton.setBounds(100, 30, 70, 30);
		borrowButton.addActionListener(new borrowBookController());
		returnButton.setBounds(250, 30, 70, 30);
		returnButton.addActionListener(new returnBookController());
		brJPanel.add(borrowButton);
		brJPanel.add(returnButton);
		leftJPanel.add(brJPanel);
		
		container.add(leftJPanel);
		
		//�ұ߲���
		JPanel rightJPanel = new JPanel();
		//���ɱ�����ʽ
		rightJPanel.setBorder(new LineBorder(Color.white));
		rightJPanel.setLayout(new BorderLayout());    //Ϊ��������һ��������
		JTable table = new JTable();
		String[] columnNames = new String[] {"���", "ͼ������", "����", "������", "״̬"};
		tableModel = (DefaultTableModel) table.getModel();
		tableModel.setColumnIdentifiers(columnNames);
		fillTable(tableModel);                             //������ʾ��Ϣ
		table.setRowHeight(35);   							//�����и�
		//���ĳ�б�ѡ�� ������ڱ�ǩ����ʾ��Ӧ����Ϣ    ����һ����������¼�����
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				
				int rowNum = table.getSelectedRow();   //row����
				int num = (int) table.getValueAt(rowNum, 0);
				String name = (String) table.getValueAt(rowNum, 1);
				String writer = (String)table.getValueAt(rowNum, 2);
				String publish = (String)table.getValueAt(rowNum, 3);
				String status = (String)table.getValueAt(rowNum, 4);
				bookNumField.setText(String.valueOf(num));
				booknameField.setText(name);
				aurthorField.setText(writer);
				publishField.setText(publish);
				bookStatueField.setText(status);
				
			}
		});
		JScrollPane jsp = new JScrollPane(table);         //����һ��������
		
		/***
		 * ���Ӹ����¼�����
		 * 
		 * ***/
		allBookButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				fillTable(tableModel); 
			}
		});
		
		//�¼���Ӧ����������Ϊ��ʹ��tableModel����ֵ��֮���ٽ��е���
		checkBookButton.addActionListener(new checkBookControllr(tableModel));     
		
		rightJPanel.add(jsp, BorderLayout.CENTER);
		container.add(rightJPanel);
		
	}
	
	public void fillTable(DefaultTableModel tableModel) {
		tableModel.setRowCount(0);
		bookDao.checkInfo(tableModel);
	}

	class borrowBookController implements ActionListener {
		//�����޸Ľ�����Ϣ���� ����Ҫ���� ���ڽ����˵���Ϣ  ֻ�� �����߿��Ի���
		@Override
		public void actionPerformed(ActionEvent e) {
			int book_id = Integer.parseInt(bookNumField.getText());
			if (bookDao.borrowBook(book_id)) {
				BrowrroAndReturnInfoDao bbc = new BrowrroAndReturnInfoDao(book_id, name);
				bbc.addBrowrroInfo();             //������ĵ���Ϣ
				JOptionPane.showMessageDialog(checkBookFrame, "���ĳɹ���");
				fillTable(tableModel);
			}else {
				JOptionPane.showMessageDialog(checkBookFrame, "����ʧ�ܣ�");
			}
		}
	}
	
	
	class returnBookController implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			int book_id = Integer.parseInt(bookNumField.getText());
			BrowrroAndReturnInfoDao bbc = new BrowrroAndReturnInfoDao(book_id, name);
			
			if (bbc.modBrowrroInfo()) {
				if (bookDao.returnBook(book_id)) {
					JOptionPane.showMessageDialog(checkBookFrame, "�黹�ɹ���");
					fillTable(tableModel);
				}else {
					JOptionPane.showMessageDialog(checkBookFrame, "�黹ʧ�ܣ�");
				}
			}else {
				JOptionPane.showMessageDialog(checkBookFrame, "�黹ʧ�ܣ�");
			}
		}
	}
	
	class checkBookControllr implements ActionListener {
		DefaultTableModel tableModel;
		public checkBookControllr(DefaultTableModel tableModel) {
			this.tableModel = tableModel;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			String checkWay = (String) comboBox.getSelectedItem();
			String sql = null;
			String checkBook = bookCheckJTextField.getText();
			
			if (checkWay.equals("ͼ������")) {
				sql = "select * from book where book_name=?";
			}else if(checkWay.equals("����")){
				sql = "select * from book where book_writer=?";
			}else if (checkWay.equals("������")) {
				sql = "select * from book where book_publish=?";
			}
			
			if (!(bookDao.checkBook(sql, checkBook, tableModel))) {
				JOptionPane.showMessageDialog(checkBookFrame, "δ�ҵ������Ϣ��");
			}
		}
	}
	
//	public static void main(String[] args) {
//		new CheckBookFrame();
//	}
}
