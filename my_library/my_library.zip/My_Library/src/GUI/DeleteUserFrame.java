package GUI;

import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.naming.InitialContext;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Dao.AdminDao;


//ɾ���û�����
public class DeleteUserFrame extends JFrame{
	private JFrame delUserFrame = new JFrame();
	private Container container = delUserFrame.getContentPane();
	private JLabel usernumLabel = new JLabel("�û����");
	private JTextField userTextField = new JTextField();
	private JButton delButton = new JButton("ɾ�����û�");
	
	AdminDao adminDao = new AdminDao();
	
	public DeleteUserFrame() {
		delUserFrame.setSize(600, 400);
		delUserFrame.setLocation(750, 250);
		delUserFrame.setTitle("ɾ���û�����");
		delUserFrame.setResizable(false);
		
		container.setLayout(new GridLayout(2, 1));
		ini();
		
		delUserFrame.setVisible(true);
		delUserFrame.setDefaultCloseOperation(delUserFrame.DISPOSE_ON_CLOSE);
		
	}
	
	private void ini() {
		//�û����
		JPanel usernumJPanel = new JPanel();
		usernumJPanel.setLayout(null);
		usernumLabel.setBounds(120, 100, 100, 40);
		usernumLabel.setFont(new Font("����", Font.BOLD, 20));
		userTextField.setBounds(225, 100, 250, 40);
		usernumJPanel.add(usernumLabel);
		usernumJPanel.add(userTextField);
		container.add(usernumJPanel);
		
		//ȷ�ϰ�ť
		JPanel delButJPanel = new JPanel();
		delButJPanel.setLayout(null);
		delButton.setBounds(225, 25, 180, 40);
		delButton.addActionListener(new ActionListener() {
			//����ɾ���û����¼�����
			@Override
			public void actionPerformed(ActionEvent e) {
				int userNum = Integer.parseInt(userTextField.getText());
				if (adminDao.CheckUser(userNum)) {
					int option = JOptionPane.showConfirmDialog(delUserFrame, "�Ƿ�ɾ�����û���");
					if (JOptionPane.OK_OPTION == option) {
						if(adminDao.delUser(userNum)) {
							JOptionPane.showMessageDialog(delUserFrame, "�ѳɹ�ɾ�����û���");
						}
					}
				}else {
					JOptionPane.showMessageDialog(delUserFrame, "δ�ҵ����û���");
				}
			}
		});
		delButJPanel.add(delButton);
		container.add(delButJPanel);
	}

//	public static void main(String[] args) {
//		new DeleteUserFrame();
//	}

}
