package GUI;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;


//����Ա��������
public class AdminOperationFrame extends JFrame{
	private JFrame useroprFrame = new JFrame();
	private Container container = useroprFrame.getContentPane();
	private JButton checkBookButton = new JButton("��ѯͼ��");
	private JButton borrowButon = new JButton("����ͼ��");
	private JButton returnButton = new JButton("�黹ͼ��");
	private JButton delBookButton = new JButton("ɾ��ͼ��");
	private JButton addBookButton = new JButton("����ͼ��");
	private JButton delUserButton = new JButton("ɾ���û�");
	private JButton checkUserButton = new JButton("��ѯ�û�");
	private ButtonController bc = new ButtonController();
	
	private String name;
	
	public AdminOperationFrame(String name) {
		this.name = name;
		useroprFrame.setSize(500, 800); 
		useroprFrame.setLocation(725, 100);
		useroprFrame.setTitle("����Ա��������");
		useroprFrame.setResizable(false);
		
		container.setLayout(new GridLayout(7, 1));        
		ini();
		
		useroprFrame.setVisible(true);
		useroprFrame.setDefaultCloseOperation(useroprFrame.DISPOSE_ON_CLOSE);
	}
	
	private void ini() {
		//��ѯͼ��
		JPanel checkbuttonJPanel = new JPanel();
		checkbuttonJPanel.setLayout(null);
		checkBookButton.setBounds(150, 20, 200, 40);
		checkBookButton.addActionListener(bc);
		checkbuttonJPanel.add(checkBookButton);
		container.add(checkbuttonJPanel);
		
		//����ͼ��
		JPanel borrowbuttonJPanel = new JPanel();
		borrowbuttonJPanel.setLayout(null);
		borrowButon.setBounds(150, 20, 200, 40);
		borrowButon.addActionListener(bc);
		borrowbuttonJPanel.add(borrowButon);
		container.add(borrowbuttonJPanel);
		
		//�黹ͼ��
		JPanel returnbuttonJPanel = new JPanel();
		returnbuttonJPanel.setLayout(null);
		returnButton.setBounds(150, 20, 200, 40);
		returnButton.addActionListener(bc);
		returnbuttonJPanel.add(returnButton);
		container.add(returnbuttonJPanel);
		
		//ɾ��ͼ��
		JPanel delBookJPanel = new JPanel();
		delBookJPanel.setLayout(null);
		delBookButton.setBounds(150, 20, 200, 40);
		//�����¼�����
		delBookButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new DeleteBookFrame();
			}
		});
		delBookJPanel.add(delBookButton);
		container.add(delBookJPanel);
		
		//����ͼ��
		JPanel addBookJPanel = new JPanel();
		addBookJPanel.setLayout(null);
		addBookButton.setBounds(150, 20, 200, 40);
		addBookButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AddBookFrame();
			}
		});
		addBookJPanel.add(addBookButton);
		container.add(addBookJPanel);
		
		//ɾ���û�
		JPanel delUserJPanel = new JPanel();
		delUserJPanel.setLayout(null);
		delUserButton.setBounds(150, 20, 200, 40);
		delUserButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new DeleteUserFrame();
			}
		});
		delUserJPanel.add(delUserButton);
		container.add(delUserJPanel);
		
		//��ѯ�û�
		JPanel checkUserJPanel = new JPanel();
		checkUserJPanel.setLayout(null);
		checkUserButton.setBounds(150, 20, 200, 40);
		checkUserButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new CheckUserFrame();
			}
		});
		checkUserJPanel.add(checkUserButton);
		container.add(checkUserJPanel);
		
	}

//	public static void main(String[] args) {
//		new AdminOperationFrame();
//		
//	}

	class ButtonController implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			new CheckBookFrame(name);
		}
		
	}
	
}
