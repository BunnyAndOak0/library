package GUI;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.peer.ButtonPeer;

import javax.naming.InitialContext;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import Dao.ReaderDao;


//�û�ע�����
public class RegisterFrame extends JFrame{
	private JFrame registerJF = new JFrame();
	private Container container = registerJF.getContentPane();
	private JLabel numLabel = new JLabel("���");
	private JTextField numField = new JTextField();
	private JLabel nameLabel = new JLabel("����");
	private JTextField nameField = new JTextField();
	private JLabel teleLabel = new JLabel("�绰����");
	private JTextField teleField = new JTextField();
	private JLabel passwordLabel = new JLabel("����");
	private JPasswordField passwordField = new JPasswordField();
	private JButton registerButton = new JButton("ע��");
	private JButton clearButton = new JButton("���");
	
	private int num;
	private String name;
	private String tele;
	private String password;
	
	registerController register = new registerController();
	
	public RegisterFrame() {
		registerJF.setSize(700, 500);
		registerJF.setLocation(580, 130);
		registerJF.setTitle("ע�����");
		registerJF.setResizable(false);
		
		container.setLayout(new GridLayout(5, 1));
		ini();
		
		registerJF.setVisible(true);
		registerJF.setDefaultCloseOperation(registerJF.DISPOSE_ON_CLOSE);
	}
	
	private void ini() {
		//���
		JPanel numJPanel = new JPanel();
		numJPanel.setLayout(null);
		numLabel.setFont(new Font("����", Font.BOLD, 20));          //��ű�ǩ
		numLabel.setBounds(170, 30, 50, 30);
		numField.setBounds(270, 30, 280, 30);
		numJPanel.add(numField);
		numJPanel.add(numLabel);
		container.add(numJPanel);
		
		//����
		JPanel nameJPanel = new JPanel();
		nameJPanel.setLayout(null);
		nameLabel.setFont(new Font("����", Font.BOLD, 20));          //������ǩ
		nameLabel.setBounds(170, 30, 50, 30);
		nameField.setBounds(270, 30, 280, 30);
		nameJPanel.add(nameLabel);
		nameJPanel.add(nameField);
		container.add(nameJPanel);
		
		//�ֻ�
		JPanel teleJPanel = new JPanel();
		teleJPanel.setLayout(null);
		teleLabel.setFont(new Font("����", Font.BOLD, 20));          //�ֻ���ǩ
		teleLabel.setBounds(150, 30, 100, 30);
		teleField.setBounds(270, 30, 280, 30);
		teleJPanel.add(teleLabel);
		teleJPanel.add(teleField);
		container.add(teleJPanel);
		
		
		//����
		JPanel passwordJPanel = new JPanel();
		passwordJPanel.setLayout(null);
		passwordLabel.setFont(new Font("����", Font.BOLD, 20));          //������ǩ
		passwordLabel.setBounds(170, 30, 50, 30);
		passwordField.setBounds(270, 30, 280, 30);
		passwordJPanel.add(passwordLabel);
		passwordJPanel.add(passwordField);
		container.add(passwordJPanel);
		
		//��ť
		JPanel buttonJPanel = new JPanel();
		buttonJPanel.setLayout(null);
		registerButton.setBounds(150, 20, 70, 45);
		registerButton.addActionListener(register);
		clearButton.setBounds(500, 20, 70, 45);
		clearButton.addActionListener(new ActionListener() {
			@Override
			//�������
			public void actionPerformed(ActionEvent e) {
				numField.setText("");
				nameField.setText("");
				teleField.setText("");
				passwordField.setText("");
			}
		});
		buttonJPanel.add(registerButton);
		buttonJPanel.add(clearButton);
		container.add(buttonJPanel);
		
	}
	
	class registerController implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			num = Integer.valueOf(numField.getText());
			name = nameField.getText();
			tele = teleField.getText();
			password = String.valueOf(passwordField.getPassword());
			if (new ReaderDao().registerReader(num, name, tele, password)) {
				JOptionPane.showMessageDialog(registerJF, "�ѳɹ�ע�ᣡ");
			}else {
				JOptionPane.showMessageDialog(registerJF, "ע��ʧ�ܣ�");
			}
			
		}
		
	}
	
//	public static void main(String[] args) {
//		new RegisterFrame();
//	}
}
