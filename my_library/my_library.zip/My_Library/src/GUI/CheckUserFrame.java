package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.naming.InitialContext;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import Dao.ReaderDao;

//��ѯ�û�����
public class CheckUserFrame extends JFrame{
	private JFrame checkUserFrame = new JFrame();
	private Container container = checkUserFrame.getContentPane();
	private JLabel userNameJLabel = new JLabel("�û����");
	private JTextField userNameField = new JTextField();
	private JButton allButton = new JButton("��ʾ�����û�");
	private JButton checkButton = new JButton("����");
	
	DefaultTableModel tableModel;
	private CheckController cc = new CheckController();
	private allController ac = new allController();
	private ReaderDao readerDao = new ReaderDao();
	
	public CheckUserFrame() {
		checkUserFrame.setSize(800, 500);
		checkUserFrame.setLocation(600, 250);
		checkUserFrame.setTitle("��ѯ�û�����");
		checkUserFrame.setResizable(false);
		
		container.setLayout(new GridLayout(1, 2));
		ini();
		
		checkUserFrame.setVisible(true);
		checkUserFrame.setDefaultCloseOperation(checkUserFrame.DISPOSE_ON_CLOSE);
	}
	
	private void ini() {
		//��߲���
		JPanel leftJPanel = new JPanel();
		leftJPanel.setLayout(new BorderLayout());
		//��߱���
		JTable userInfoJTable = new JTable();
		tableModel = (DefaultTableModel) userInfoJTable.getModel();
		String[] column = new String[] {"���", "����", "�绰", "����"};
		tableModel.setColumnIdentifiers(column);
		userInfoJTable.setRowHeight(35);
		JScrollPane jsp = new JScrollPane(userInfoJTable);
		readerDao.allReader(tableModel);
		leftJPanel.add(jsp, BorderLayout.CENTER);
		
		container.add(leftJPanel);
		
		//�ұ߲���
		JPanel rightJPanel = new JPanel();
		rightJPanel.setLayout(new GridLayout(2, 1));
		//�û���ű�ǩ����
		JPanel usernumJPanel = new JPanel();
		usernumJPanel.setLayout(null);
		userNameJLabel.setFont(new Font("����", Font.BOLD, 20));
		userNameJLabel.setBounds(50, 100, 100, 30);
		userNameField.setBounds(150, 100, 175, 30);
		usernumJPanel.add(userNameJLabel);
		usernumJPanel.add(userNameField);
		rightJPanel.add(usernumJPanel);
		//��ť����
		JPanel checkUserJPanel = new JPanel();
		checkUserJPanel.setLayout(null);
		allButton.setBounds(50, 50, 125, 50);
		allButton.addActionListener(ac);
		checkButton.setBounds(220, 50, 125, 50);
		checkButton.addActionListener(cc);
		checkUserJPanel.add(allButton);
		checkUserJPanel.add(checkButton);
		rightJPanel.add(checkUserJPanel);
		
		container.add(rightJPanel);
	}
	
	
	class CheckController implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			int readerNum = Integer.parseInt(userNameField.getText());
			if (!(readerDao.checkReader(readerNum, tableModel))) 
				JOptionPane.showMessageDialog(checkUserFrame, "δ�ҵ����û���");
		}
	}
	
	class allController implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			tableModel.setRowCount(0);
			readerDao.allReader(tableModel);
		}
		
	}

//	public static void main(String[] args) {
//		new CheckUserFrame();
//	}
	
}
