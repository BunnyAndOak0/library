package GUI;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import Dao.AdminDao;
import Dao.ReaderDao;
import Model.Admin;
import Model.Reader;


//��½����
public class LoginFrame extends JFrame{
	private JFrame jf = new JFrame("ͼ��ݹ���ϵͳ��¼");
	private Container container = jf.getContentPane();
	private JLabel userchoseJLabel = new JLabel("�û�");
	private JRadioButton userChose = new JRadioButton();
	private JLabel adminchoseJLabel = new JLabel("����Ա");
	private JRadioButton adminChose = new JRadioButton();
 	private JLabel userNameJLable = new JLabel("�û���");
	private JTextField userName = new JTextField();
	private JLabel userPasswordJLabel = new JLabel("����");
	private JPasswordField passWord = new JPasswordField();
	private JButton loginBut = new JButton("��¼");
	private JButton registerBut = new JButton("ע��");
	
	AdminDao adminDao = new AdminDao();
	ReaderDao readerDao = new ReaderDao();
	
	String name;
	String password;
	
	public LoginFrame() {
		jf.setSize(800, 500);
		jf.setLocation(650, 250);
		jf.setTitle("��½����");
		jf.setResizable(false);
		
		container.setLayout(new GridLayout(5, 1));
		ini();        //��������������ؼ�
		
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void ini() {
		//���ⲿ��
		
		JPanel titleJPanel = new JPanel();
		titleJPanel.setLayout(new FlowLayout());
		JLabel titLabel = new JLabel("ͼ��ݹ���ϵͳ");
		titLabel.setFont(new Font("����", Font.BOLD, 30));
		titLabel.setForeground(Color.BLUE);
		titleJPanel.setSize(800, 30);
		titleJPanel.add(titLabel);
		container.add(titleJPanel);
		
		//ѡ�񲿷�
		JPanel choceJPanel = new JPanel();
		choceJPanel.setLayout(null);
		userchoseJLabel.setFont(new Font("����", Font.BOLD, 15));
		userchoseJLabel.setBounds(200, 25, 50, 30);
		userChose.setBounds(250, 25, 50, 30);       //��ѡ��
		adminchoseJLabel.setFont(new Font("����", Font.BOLD, 15));
		adminchoseJLabel.setBounds(525, 25, 50, 30);
		adminChose.setBounds(590, 25, 50, 30);
		ButtonGroup bg = new ButtonGroup();      //����ButtonGroup��ʹ�õ�ѡ��ֻ��ѡ��һ��
		bg.add(userChose); 
		bg.add(adminChose);
		choceJPanel.add(userchoseJLabel);
		choceJPanel.add(adminchoseJLabel);
		choceJPanel.add(userChose);
		choceJPanel.add(adminChose);
		container.add(choceJPanel);
		
		//���벿��
		JPanel userfiledPanel = new JPanel();
		JPanel passwordfilJPanel = new JPanel();
		userfiledPanel.setLayout(null);
		passwordfilJPanel.setLayout(null);
		userNameJLable.setBounds(210, 0, 100, 60);
		userNameJLable.setFont(new Font("����", Font.BOLD, 20));
		userName.setBounds(310, 15, 250, 30);
		userfiledPanel.add(userNameJLable);
		userfiledPanel.add(userName);
		userPasswordJLabel.setBounds(210, 5, 100, 60);
		userPasswordJLabel.setFont(new Font("����", Font.BOLD, 20));
		passWord.setBounds(310, 20, 250, 30);
		passwordfilJPanel.add(userPasswordJLabel);
		passwordfilJPanel.add(passWord);
		container.add(userfiledPanel);
		container.add(passwordfilJPanel);
		
		//��ť����
		JPanel buttonJPanel = new JPanel();
		buttonJPanel.setLayout(null);
		loginBut.setBounds(250, 0, 70, 45);
		registerBut.setBounds(475, 0, 70, 45);
		buttonJPanel.add(loginBut);
		//��¼��ť�����¼�����
		loginBut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				getValue();
				
				if (userName.getText().equals("")) {
					JOptionPane.showMessageDialog(jf, "�û�������Ϊ��!");
				}else if (String.valueOf(passWord.getPassword()).equals("")) {
					JOptionPane.showMessageDialog(jf, "���벻��Ϊ��!");
				}else if (!(userChose.isSelected()) && !(adminChose.isSelected())) {
					JOptionPane.showMessageDialog(jf, "��ѡ���¼��ʽ!");
				}else if (userChose.isSelected()) {
					if (readerLogin()) {
						new UserOperationFrame(name);
					}else {
						JOptionPane.showMessageDialog(jf, "�û������������");
					}
				}else if (adminChose.isSelected()) {
					if (adminLogin()) {
						new AdminOperationFrame("����Ա" + name);
					}else {
						JOptionPane.showMessageDialog(jf, "�û����������");
					}
				}
			}
			
		});
		
		buttonJPanel.add(registerBut);
		registerBut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new RegisterFrame();
			}
		});
		
		container.add(buttonJPanel);
				
	}
	
	public void getValue() {
		name = userName.getText();          //��ȡ�û����������ֵ��
		password = String.valueOf(passWord.getPassword());
	}
	
	public boolean adminLogin() {
		if (adminDao.login(name, password)) {
			return true;
		}
		return false;
	}
	
	public boolean readerLogin() {
		if (readerDao.loginReader(name, password)) {
			return true;
		}
		return false;
	}
	
}
