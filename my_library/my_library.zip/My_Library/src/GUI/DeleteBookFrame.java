package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import Dao.BookDao;
import javafx.scene.layout.Border;


//ɾ��ͼ�����
public class DeleteBookFrame extends JFrame{
	private JFrame deleteBookFrame = new JFrame();
	private Container container = deleteBookFrame.getContentPane();
	private JButton delButton = new JButton("ɾ��");
	
	BookDao bookDao = new BookDao();
	
	public DeleteBookFrame() {
		deleteBookFrame.setSize(1000, 700);
		deleteBookFrame.setLocation(500, 150);
		deleteBookFrame.setTitle("ɾ��ͼ�����");
		deleteBookFrame.setResizable(false);
		
		container.setLayout(new GridLayout(1, 2));     //��������Ϊ����������
		ini();
		
		deleteBookFrame.setVisible(true);
		deleteBookFrame.setDefaultCloseOperation(deleteBookFrame.DISPOSE_ON_CLOSE);
		
	}
	
	private void ini() {
 		//��߲���
		JPanel leftJPanel = new JPanel();
		//���ɱ�����ʽ
		leftJPanel.setBorder(new LineBorder(Color.white));
		leftJPanel.setLayout(new BorderLayout());    //Ϊ��������һ��������
		JTable bookJTable = new JTable();
		String[] columnNames = new String[] {"���", "ͼ������", "����", "������", "״̬"};
		DefaultTableModel bookModel = (DefaultTableModel) bookJTable.getModel();
		bookModel.setColumnIdentifiers(columnNames);
		bookDao.checkInfo(bookModel);
		bookJTable.setRowHeight(35);   							//�����и�
		JScrollPane jsp = new JScrollPane(bookJTable);         //����һ��������
		leftJPanel.add(jsp, BorderLayout.CENTER);
		container.add(leftJPanel);
		
		//�ұ߲���
		JPanel righJPanel = new JPanel();
		righJPanel.setLayout(null);
		delButton.setBounds(200, 250, 150, 40);
		delButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int bookNum = bookJTable.getSelectedRow();
				int book_id = (int) bookJTable.getValueAt(bookNum, 0);
				int option = JOptionPane.showConfirmDialog(deleteBookFrame, "ȷ��ɾ����ͼ����");
				if (JOptionPane.OK_OPTION == option) {
					if (bookDao.delBook(book_id, bookModel)) {
						if (JOptionPane.OK_OPTION == option) {
							JOptionPane.showMessageDialog(deleteBookFrame, "ͼ��ɾ���ɹ���");
						}
					}else {
						JOptionPane.showMessageDialog(deleteBookFrame, "��ͼ�黹δ�黹������ɾ����");
					}
					bookModel.setRowCount(0);
					bookDao.checkInfo(bookModel);
				}
			}
		});
		righJPanel.add(delButton);
		container.add(righJPanel);
		
	}

//	public static void main(String[] args) {
//		new DeleteBookFrame();
//	}
}
