package GUI;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.peer.ButtonPeer;
import java.sql.PreparedStatement;

import javax.naming.InitialContext;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import Dao.BookDao;

//����ͼ�����
public class AddBookFrame extends JFrame{
	private JFrame addBookJF = new JFrame();
	private Container container = addBookJF.getContentPane();
	private JLabel bookNumLabel = new JLabel("ͼ����");
	private JTextField bookNumField = new JTextField();
	private JLabel bookNameLabel = new JLabel("ͼ������");
	private JTextField bookNameField = new JTextField();
	private JLabel bookAurLabel = new JLabel("ͼ������");
	private JTextField bookAurField = new JTextField();
	private JLabel publishLabel = new JLabel("������");
	private JTextField publishField = new JTextField();;
	private JLabel bookStatueLabel = new JLabel("ͼ��״̬");
	private JTextField bookStatueField = new JTextField();
	private JButton addButton = new JButton("����");
	
	public AddBookFrame() {
		addBookJF.setSize(700, 600);
		addBookJF.setLocation(580, 130);
		addBookJF.setTitle("����ͼ�����");
		addBookJF.setResizable(false);
		
		container.setLayout(new GridLayout(6, 1));
		ini();
		
		addBookJF.setVisible(true);
		addBookJF.setDefaultCloseOperation(addBookJF.DISPOSE_ON_CLOSE);
	}
	
	private void ini() {
		//ͼ����
		JPanel booknumJPanel = new JPanel();
		booknumJPanel.setLayout(null);
		bookNumLabel.setFont(new Font("����", Font.BOLD, 20));          //��ű�ǩ
		bookNumLabel.setBounds(170, 30, 100, 30);
		bookNumField.setBounds(270, 30, 280, 30);
		booknumJPanel.add(bookNumLabel);
		booknumJPanel.add(bookNumField);
		container.add(booknumJPanel);
		
		//ͼ������
		JPanel bookNameJPanel = new JPanel();
		bookNameJPanel.setLayout(null);
		bookNameLabel.setFont(new Font("����", Font.BOLD, 20));          //��ű�ǩ
		bookNameLabel.setBounds(170, 30, 100, 30);
		bookNameField.setBounds(270, 30, 280, 30);
		bookNameJPanel.add(bookNameLabel);
		bookNameJPanel.add(bookNameField);
		container.add(bookNameJPanel);
		
		//ͼ������
		JPanel bookAurJPanel = new JPanel();
		bookAurJPanel.setLayout(null);
		bookAurLabel.setFont(new Font("����", Font.BOLD, 20));          //��ű�ǩ
		bookAurLabel.setBounds(170, 30, 100, 30);
		bookAurField.setBounds(270, 30, 280, 30);
		bookAurJPanel.add(bookAurLabel);
		bookAurJPanel.add(bookAurField);
		container.add(bookAurJPanel);
		
		//������
		JPanel publishJPanel = new JPanel();
		publishJPanel.setLayout(null);
		publishLabel.setFont(new Font("����", Font.BOLD, 20));          //������ǩ
		publishLabel.setBounds(170, 30, 100, 30);
		publishField.setBounds(270, 30, 280, 30);
		publishJPanel.add(publishLabel);
		publishJPanel.add(publishField);
		container.add(publishJPanel);
		
		//״̬
		JPanel bookStatueJPanel = new JPanel();
		bookStatueJPanel.setLayout(null);
		bookStatueLabel.setFont(new Font("����", Font.BOLD, 20));          //��ű�ǩ
		bookStatueLabel.setBounds(170, 30, 100, 30);
		bookStatueField.setBounds(270, 30, 280, 30);
		bookStatueJPanel.add(bookStatueLabel);
		bookStatueJPanel.add(bookStatueField);
		container.add(bookStatueJPanel);
		
		//��ť
		JPanel addJPanel = new JPanel();
		addJPanel.setLayout(null);
		addButton.setBounds(325, 20, 85, 45);
		addButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				BookDao bookDao = new BookDao();
				if (bookDao.addBook(Integer.valueOf(bookNumField.getText()), bookNameField.getText(), 
						bookAurField.getText(), publishField.getText(), bookStatueField.getText())) {
					JOptionPane.showMessageDialog(addBookJF, "ͼ���ѳɹ����ӣ�");
				}else {
					JOptionPane.showMessageDialog(addBookJF, "ͼ��δ���ӳɹ���");
				}
			}
		});
		addJPanel.add(addButton);
		container.add(addJPanel);
		
	}

//	public static void main(String[] args) {
//		new AddBookFrame();
//	}

}
