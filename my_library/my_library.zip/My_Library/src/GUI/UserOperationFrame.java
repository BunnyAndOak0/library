package GUI;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


//�û��ɲ�������
public class UserOperationFrame extends JFrame{
	private JFrame useroprFrame = new JFrame();
	private Container container = useroprFrame.getContentPane();
	private JButton checkButton = new JButton("��ѯͼ��");
	private JButton borrowButon = new JButton("����ͼ��");
	private JButton returnButton = new JButton("�黹ͼ��");
	ButtonController bc = new ButtonController();
	
	private String name;
	
	public UserOperationFrame(String name) {
		this.name = name;
		useroprFrame.setSize(500, 300); 
		useroprFrame.setLocation(725, 250);
		useroprFrame.setTitle("�û���������");
		useroprFrame.setResizable(false);
		
		container.setLayout(new GridLayout(3, 1));        //����һ��
		ini();
		
		useroprFrame.setVisible(true);
		useroprFrame.setDefaultCloseOperation(useroprFrame.DISPOSE_ON_CLOSE);
	}
	
	private void ini() {
		//����ͼ��
		JPanel checkbuttonJPanel = new JPanel();
		checkbuttonJPanel.setLayout(null);
		checkButton.setBounds(150, 20, 200, 40);
		checkButton.addActionListener(bc);
		checkbuttonJPanel.add(checkButton);
		container.add(checkbuttonJPanel);
		
		//����ͼ��
		JPanel borrowbuttonJPanel = new JPanel();
		borrowbuttonJPanel.setLayout(null);
		borrowButon.setBounds(150, 20, 200, 40);
		borrowButon.addActionListener(bc);
		borrowbuttonJPanel.add(borrowButon);
		container.add(borrowbuttonJPanel);
		
		//�黹ͼ��
		JPanel returnbuttonJPanel = new JPanel();
		returnbuttonJPanel.setLayout(null);
		returnButton.setBounds(150, 20, 200, 40);
		returnButton.addActionListener(bc);
		returnbuttonJPanel.add(returnButton);
		container.add(returnbuttonJPanel);
		
	}

//	public static void main(String[] args) {
//		new UserOperationFrame();
//	}
//	
	class ButtonController implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			new CheckBookFrame(name);
		} 
		
	}
}
