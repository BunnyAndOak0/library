package Model;

public class Reader {
	private int reader_id;
	private String reader_name;
	private String reader_phone;
	private String reader_password;
	
	public Reader() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Reader(String reader_name) {
		super();
		this.reader_name = reader_name;
	}

	public int getReader_id() {
		return reader_id;
	}
	public void setReader_id(int reader_id) {
		this.reader_id = reader_id;
	}
	public String getReader_name() {
		return reader_name;
	}
	public void setReader_name(String reader_name) {
		this.reader_name = reader_name;
	}
	public String getReader_phone() {
		return reader_phone;
	}
	public void setReader_phone(String reader_phone) {
		this.reader_phone = reader_phone;
	}
	public String getReader_password() {
		return reader_password;
	}
	public void setReader_password(String reader_password) {
		this.reader_password = reader_password;
	}
	
	

}
