package Model;


//����Աֻ�����Լ������ݿ��ֶ����� û������ע��
public class Admin {
	private int admin_id;
	private String admin_name;
	private String admin_tele;
	private String admin_password;
	
	public Admin() {
		super();
	}
	
	public Admin(String admin_name) {
		super();
		this.admin_name = admin_name;
	}

	public int getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getAdmin_tele() {
		return admin_tele;
	}
	public void setAdmin_tele(String admin_tele) {
		this.admin_tele = admin_tele;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	
	

}
