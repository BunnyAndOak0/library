package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import GUI.CheckUserFrame;
import Model.Admin;
import Util.Connect;

public class AdminDao {
	Connect c = new Connect();
	
	public Boolean login(String name, String password) {
		String sql = "select * from admin where admin_name=? and admin_password=?";
		try (Connection conn = c.getConn();
			 PreparedStatement ps = conn.prepareStatement(sql);){
			ps.setString(1, name);
			ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	
	public boolean CheckUser(int userNum) {
		String sql = "select * from reader where reader_id=?";
		
		try(Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);) {
			ps.setInt(1, userNum);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean delUser(int userNum) {
		String sql = "delete from reader where reader_id=?";
		
		try(Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);) {
				ps.setInt(1, userNum);
				
				ps.execute();
				return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return false;
	}

}
