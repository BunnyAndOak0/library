package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sun.org.apache.bcel.internal.generic.NEW;

import Util.Connect;

public class BrowrroAndReturnInfoDao {
	private int book_id;
	private String name;
	private Date bDate = new Date();        //��������
	private Date rDate = new Date();        //��������
	private String status = "�ѽ��";
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Connect c = new Connect();
	
	public BrowrroAndReturnInfoDao(int book_id, String name) {
		this.book_id = book_id;
		this.name = name;
	}
	
	//���ӽ�����Ϣ
	public void addBrowrroInfo() {
		Connection conn = c.getConn();
		
		String sql = "select * from book_info where book_id=?";
		try (PreparedStatement ps = conn.prepareStatement(sql)){
			ps.setInt(1, book_id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {       //�Ѿ����ڴ˼�¼ �Ϳ���ֱ���޸�    ���������Ѿ�����������
				String sql1 = "update book_info set reader_name=?, borrow_date=?, return_date=null, book_status=? where book_id=?";
				PreparedStatement ps1 = conn.prepareStatement(sql1);
				ps1.setString(1, name);
				ps1.setString(2, sdf.format(bDate));
				ps1.setString(3, status);
				ps1.setInt(4, book_id);
				ps1.execute();
			}else {
				String sql2 = "insert into book_info values(?, ?, ?, ?, ?)";
				try (PreparedStatement ps2 = conn.prepareStatement(sql2);){
					
					ps2.setInt(1, book_id);
					ps2.setString(2, name);
					ps2.setString(3, sdf.format(bDate));
					ps2.setString(4, null);
					ps2.setString(5, status);
					ps2.execute();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	
	public boolean modBrowrroInfo() {
		Connection conn = c.getConn();
		String sql = "select * from book_info where book_id=? and reader_name=?";
		try (PreparedStatement ps = conn.prepareStatement(sql);){
			ps.setInt(1, book_id);
			ps.setString(2, name);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				String sql1 = "update book_info set book_status='�ѹ黹', return_date=? where book_id=?";
				PreparedStatement ps1 = conn.prepareStatement(sql1);
				ps1.setString(1, sdf.format(rDate));
				ps1.setInt(2, book_id);
				
				ps1.execute();
				return true;
			}
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	
//	public static void main(String[] args) {
//		new BrowrroAndReturnInfoDao(1, "���").addBrowrroInfo();
//	}

}
