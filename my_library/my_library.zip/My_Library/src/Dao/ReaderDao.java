package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Util.Connect;

public class ReaderDao {
	Connect c = new Connect();

	public boolean registerReader(int num, String name, String tele, String password) {
		String sql = "insert into reader values(?, ?, ?, ?)";
		
		try (Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
			
			ps.setInt(1, num);
			ps.setString(2, name);
			ps.setString(3, tele);
			ps.setString(4, password);
			
			ps.execute();
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;		
	}
	
	public boolean loginReader(String name, String password) {
		String sql = "select * from reader where reader_name=? and reader_password=?";
		
		try (Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
			
			ps.setString(1, name);
			ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean checkReader(int readerNum, DefaultTableModel tableModel) {
		String sql = "select * from reader where reader_id=?";
		
		try (Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql)){
			
			ps.setInt(1, readerNum);
			
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				tableModel.setRowCount(0);
				ArrayList arrays = new ArrayList();
				arrays.add(rs.getInt(1));
				arrays.add(rs.getString(2));
				arrays.add(rs.getString(3));
				arrays.add(rs.getString(4));
				
				Vector vector = new Vector();
				vector.add(arrays.get(0));
				vector.add(arrays.get(1));
				vector.add(arrays.get(2));
				vector.add(arrays.get(3));
				
				tableModel.addRow(vector);
				
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public void allReader(DefaultTableModel tableModel) {
		String sql = "select * from reader";
		
		try (Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql)){
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ArrayList arrays = new ArrayList();
				arrays.add(rs.getInt(1));
				arrays.add(rs.getString(2));
				arrays.add(rs.getString(3));
				arrays.add(rs.getString(4));
				
				Vector vector = new Vector();
				vector.add(arrays.get(0));
				vector.add(arrays.get(1));
				vector.add(arrays.get(2));
				vector.add(arrays.get(3));
				
				tableModel.addRow(vector);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
