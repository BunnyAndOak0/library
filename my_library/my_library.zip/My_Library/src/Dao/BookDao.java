package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

import GUI.AddBookFrame;
import Util.Connect;

public class BookDao {
	Connect c = new Connect();
	
	public boolean addBook(int id, String name, String writer, String publish, String status) {
		String sql = "insert into book values(?, ?, ?, ? ,?);";
		
		try (Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
			
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3, writer);
			ps.setString(4, publish);
			ps.setString(5, status);
			
			ps.execute();
			
			return true;
			
		} catch (SQLException e) {
			// 
			e.printStackTrace();
		}
		return false;
	}
	
	public void checkInfo(DefaultTableModel tabelModel) {   //��ѯ���ݿ��е�������Ϣ
		String sql = "select * from book";
		DefaultTableModel tableModel = tabelModel;
		
		try(Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql)) {
			
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ArrayList arrays = new ArrayList();
				Vector vector = new Vector();
				
				int book_id = rs.getInt("book_id");
				String book_name = rs.getString(2);
				String book_writer = rs.getString("book_writer");
				String book_publish = rs.getString("book_publish");
				String book_stauts = rs.getString(5);
				
				arrays.add(book_id);
				arrays.add(book_name);
				arrays.add(book_writer);
				arrays.add(book_publish);
				arrays.add(book_stauts);
				
				vector.add(arrays.get(0));
				vector.add(arrays.get(1));
				vector.add(arrays.get(2));
				vector.add(arrays.get(3));
				vector.add(arrays.get(4));
				
				tabelModel.addRow(vector);
			}
			
		} catch (SQLException e) {
			// 
			e.printStackTrace();
		}
		
	}
	
	//����ͼ�� 
	public boolean borrowBook(int book_id) {
		String sql = "select * from book where book_id=? and book_status='δ���'";
		
		try (Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
				ps.setInt(1, book_id);
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					String sql2 = "update book set book_status='�ѽ��' where book_id=?";
					try (PreparedStatement ps2 = conn.prepareStatement(sql2)){
						ps2.setInt(1, book_id);
						ps2.executeUpdate();
						return true;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				return false;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return false;
	}
	
	//�黹ͼ��
	public boolean returnBook(int book_id) {
		String sql = "select * from book where book_id=? and book_status='�ѽ��'";
		
		try (Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql);){
				ps.setInt(1, book_id);
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {        //���ڽ��ͼ���������¼
					String sql2 = "update book set book_status='δ���'  where book_id=?";
					try (PreparedStatement ps2 = conn.prepareStatement(sql2)){
						ps2.setInt(1, book_id);
						ps2.executeUpdate();
						return true;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				return false;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return false;
	}
	
	//��ѯͼ��
	public boolean checkBook(String sql, String checkInfo, DefaultTableModel tableModel) {
		try (Connection conn = c.getConn();
			PreparedStatement ps = conn.prepareStatement(sql)){
			
			ps.setString(1, checkInfo);
			
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				tableModel.setRowCount(0);
				do {
					ArrayList arrays = new ArrayList();
					arrays.add(rs.getInt(1));
					arrays.add(rs.getString(2));
					arrays.add(rs.getString(3));
					arrays.add(rs.getString(4));
					arrays.add(rs.getString(5));
					
					Vector vector = new Vector();
					vector.add(arrays.get(0));
					vector.add(arrays.get(1));
					vector.add(arrays.get(2));
					vector.add(arrays.get(3));
					vector.add(arrays.get(4));
					
					tableModel.addRow(vector);
					System.out.println(111);
				}while(rs.next());
				
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean delBook(int book_id, DefaultTableModel bookModel) {
		Connection conn = c.getConn();
		String checksql = "select * from book where book_id=? and book_status='δ���'";
		try (PreparedStatement ps = conn.prepareStatement(checksql);){
			ps.setInt(1, book_id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				String sql = "delete from book where book_id=?";
				try (PreparedStatement ps1 = conn.prepareStatement(sql);){
					
					ps1.setInt(1, book_id);
					ps1.execute();
					
					return true;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return false;
	}

}
